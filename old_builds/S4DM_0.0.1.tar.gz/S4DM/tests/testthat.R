library(testthat)
library(S4DM)


test_check("S4DM")
