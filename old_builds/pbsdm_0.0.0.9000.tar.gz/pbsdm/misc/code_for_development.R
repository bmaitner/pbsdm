library(devtools)
#devtools::create("C:/Users/Brian Maitner/Desktop/current_projects/pbsdm/")

devtools::load_all()
document()
build(path = "old_builds/")
install()
library(pbsdm)
element=method
set=c("ulsif", "rulsif","maxnet")





robust_in(element = "ulsif",set = set)


