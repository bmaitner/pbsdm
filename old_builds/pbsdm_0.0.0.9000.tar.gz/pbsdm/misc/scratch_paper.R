
library(BIEN)

xs <- BIEN_occurrence_species(species = "Xanthium strumarium",
                              only.new.world = T)

library(raster)

env <- getData("worldclim", var = "bio", res = 10)

# To make things a bit faster and easier, we'll limit ourselves to the 2 variables (mean temperature and annual precipitation)

env <- env[[c("bio1","bio12")]]

# And we'll rescale the variables as well

env <- scale(env)

# Just to take a look to make sure we didn't mess anything up
plot(env)


#####################

library(pbsdm)
library(raster)
xs_rangebagged <-
  make_range_map(occurrences = xs[c("longitude","latitude")],
                 env = env,
                 presence_method = "rangebagging",
                 background_method = "none")




pred<- project_plug_and_play(pnp_model = model,data = getValues(env))
pred<-setValues(env[[1]],pred)
plot(pred)

binary<- pbsdm:::sdm_threshold(prediction_raster = pred,
                               occurrence_sp = presence_data$occurrence_sp,
                               quantile = 0.95,
                               return_binary = T)
plot(binary)


##############################################

sp.proj=CRS(paste0("+proj=laea +lat_0=",
                   center[2]," +lon_0=",
                   center[1],
                   " +x_0=0 +ellps=WGS84 +datum=WGS84 +units=m +no_defs +towgs=0,0,0"))
